exports.printMsg = function() {
    console.log("Launching exports function from static-html-output-plugin-6.6.8-gb package");
  }