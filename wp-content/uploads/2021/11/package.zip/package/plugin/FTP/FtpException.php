<?php

namespace FtpClient;

class FtpException extends \Exception
{
}
